package com.android.mystoryappcompose.ui.screen.home

data class HomeState (
    val query: String = ""
)