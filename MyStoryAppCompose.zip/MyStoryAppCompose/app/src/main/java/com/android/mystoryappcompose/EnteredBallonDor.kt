package com.android.mystoryappcompose

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EnteredBallonDor: Application()